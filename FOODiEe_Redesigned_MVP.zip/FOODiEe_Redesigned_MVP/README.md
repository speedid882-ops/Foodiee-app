# FOODiEe Multi-Restaurant MVP (Redesigned Prototype)

## Run locally
1. Extract the ZIP.
2. Open `index.html` in a browser for a quick preview.
3. For PWA/service-worker testing, serve the folder through a local HTTP server or HTTPS hosting.

## Design update
- Refined premium orange-and-cream visual system
- Responsive mobile layout, upgraded cards, buttons, forms and dashboard styling
- Typography and spacing polish

## Included
- Responsive customer website
- Three sample restaurants and menus
- Search and cuisine filter
- Cart limited to one restaurant per order
- Demo checkout form
- Browser-local demo order list and status updates
- Basic PWA manifest and service worker

## Important limitations
This is a front-end prototype only. It does **not** provide real customer accounts, a shared online order database, secure staff/admin authentication, real payment processing, refunds, vendor settlements, delivery tracking, or production-ready access control. Browser `localStorage` is used only for demo orders.

## Production architecture
- Frontend: React/Next.js or equivalent responsive PWA
- Backend: authenticated server-side API / serverless functions
- Database: PostgreSQL (e.g. Supabase) with row-level security policies
- Roles: customer, restaurant owner/staff, platform admin
- Tables: users, restaurants, menu_categories, menu_items, addresses, orders, order_items, payments, settlements, order_status_history
- Payments: approved provider with marketplace/vendor settlement support; verify signatures/webhooks on the server; never store secret keys in client code
- Deployment: commercial-use-eligible HTTPS hosting + managed database; configure environment secrets and backups
- Android: installable PWA first; package for Play Store after production hardening and policy checks

## Before live launch
1. Configure real authentication and server-side authorization.
2. Implement database policies so each restaurant can access only its own orders/menu.
3. Recalculate prices on the server and snapshot item names/prices into order_items.
4. Integrate payment provider sandbox, signed webhook verification, idempotency, refunds and settlement reconciliation.
5. Add privacy policy, terms, cancellation/refund policy, support contacts, and restaurant onboarding checks.
6. Test failures, duplicate payment callbacks, unavailable menu items, cancellations, and network interruptions.
7. Verify applicable food-business, tax, consumer-protection and payment-provider requirements for your operating model.
